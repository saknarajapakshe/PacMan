# PacMan Game Installer

## Installation Instructions:
1. Run Install.bat as Administrator
2. Choose installation directory or press Enter for default
3. Game will be installed with desktop and start menu shortcuts

## Manual Installation:
1. Copy PacMan.jar to any folder
2. Double-click RunPacMan.bat to play

## System Requirements:
- Windows 7 or later
- Java 8 or higher

## Controls:
- Arrow keys: Move PacMan
- SPACE: Pause game
- ESC: Exit game

Enjoy playing PacMan!
