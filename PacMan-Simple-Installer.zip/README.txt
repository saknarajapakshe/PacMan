PacMan Game - Simple Installer
==============================

INSTALLATION:
1. Run Install.bat
2. Game will be installed to your user folder
3. Desktop shortcut will be created

MANUAL INSTALLATION:
1. Copy PacMan.jar anywhere you want
2. Double-click RunPacMan.bat to play

REQUIREMENTS:
- Java 8 or higher
- Windows 7 or later

CONTROLS:
- Arrow Keys: Move PacMan
- SPACE: Pause

Have fun playing!
