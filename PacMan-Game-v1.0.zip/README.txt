# Pac-Man Game 
 
## How to Run: 
1. Double-click RunPacMan.bat 
2. Or run: java -jar PacMan.jar 
 
## Requirements: 
- Java 8 or higher 
 
## Controls: 
- Arrow keys to move 
- SPACE to pause 
